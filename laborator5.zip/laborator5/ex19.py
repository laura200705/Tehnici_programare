# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

response = requests.get(BASE_URL)

if response.cookies:
    for cookie in response.cookies:
        print("Nume:", cookie.name, "Secure:", cookie.secure)
else:
    print("Niciun cookie setat")