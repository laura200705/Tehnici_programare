# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

def response_times(*urls):
    result = {}

    for url in urls:
        response = requests.get(url, timeout=TIMEOUT)
        result[url] = response.elapsed.total_seconds()

    return result


print(response_times(BASE_URL,ECHO_URL))