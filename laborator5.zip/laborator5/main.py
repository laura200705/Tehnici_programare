# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

TIMEOUT = 10 # secunde

from webtools import get_title, security_headers

BASE_URL = "https://cybercor.org"

print(get_title(" <title>Test</title> "))
print(security_headers(BASE_URL))

# Dacă main.py ar avea și o funcție proprie numită get_title, numele importat din webtools ar fi înlocuit de funcția proprie.