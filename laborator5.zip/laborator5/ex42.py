# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

import socket

def resolve(hostname):
    return socket.gethostbyname(hostname)


print(resolve("cybercor.org"))