# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

def fetch(url):
    """Returnează obiectul răspuns."""
    response = requests.get(url, timeout=TIMEOUT)
    return response

response = fetch(BASE_URL)

print(response.status_code)