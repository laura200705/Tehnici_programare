# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests
import time

def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

print(get_status(BASE_URL + "/"))

time.sleep(1)

print(get_status(BASE_URL + "/robots.txt"))

time.sleep(1)

print(get_status(BASE_URL + "/sitemap.xml"))