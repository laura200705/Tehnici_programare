# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

import ssl
import socket
from datetime import datetime

def cert_days_left(hostname):
    context = ssl.create_default_context()

    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()

    expiry = ssl.cert_time_to_seconds(cert["notAfter"])
    expiry_date = datetime.fromtimestamp(expiry)
    days_left = (expiry_date - datetime.now()).days

    return days_left


print(cert_days_left("cybercor.org"))