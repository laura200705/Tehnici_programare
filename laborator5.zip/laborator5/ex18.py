# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

response = requests.get(BASE_URL)

head_response = requests.head(BASE_URL)
get_response = requests.get(BASE_URL)

print("HEAD:", len(head_response.content))
print("GET:", len(get_response.content))

# HEAD primește doar antetele, fără conținutul paginii,, avand un numar mic, sau chiar 0 iar GET primește și conținutul paginii,un numar cu mult mai mare.
