# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

from urllib.parse import urljoin

def make_urls(base, paths):
    for path in paths:
        print(urljoin(base, path))


paths = ["/about", "contact.html", "../index.html"]

make_urls(BASE_URL, paths)