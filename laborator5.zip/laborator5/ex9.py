#Laborator: functii, metode si importuri pe web
#Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 #secunde

import requests

response = requests.get(BASE_URL)

print(response.status_code) #atribut
print(response.ok)  #atribut
print(response.url)  #atribut
print(response.encoding)  #atribut
