#Laborator: functii, metode si importuri pe web
#Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 #secunde

import requests
print(dir(requests))

#'get'- functie
#'ConnectTimeout' - clasa
#'auth' - modul