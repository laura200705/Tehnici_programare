# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

response = requests.get(BASE_URL)

print(response.headers.get("Server", "lipsește"))
print(response.headers.get("Content-Type", "lipsește"))
print(response.headers.get("content-type", "lipsește"))

#cloudflare
#text/html; charset=utf-8
#text/html; charset=utf-8

#Antetele HTTP nu sunt case-sensitive, deci nu conteaza ca sunt scrie cu majuscula sau minuscula