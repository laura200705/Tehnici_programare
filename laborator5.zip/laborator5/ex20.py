# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

session = requests.Session()

session.headers.update({
    "User-Agent": "WebLab-Vizitiu Laura"
})

response = session.get(ECHO_URL + "/headers")

print(response.json())
print("User-Agent:", response.json()["headers"]["User-Agent"])

