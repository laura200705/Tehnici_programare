# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

response = requests.get(BASE_URL)
response.raise_for_status()

try:
    response = requests.get(BASE_URL + "/this-page-does-not-exist")
    print(response.status_code)
    response.raise_for_status()
except requests.HTTPError:
    print("Pagina nu exista sau nu poate fi accesata. Mai incearca :)")