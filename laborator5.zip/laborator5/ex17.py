# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

response = requests.get("http://cybercor.org")

for redirect in response.history:
    print(redirect.status_code, redirect.url)

print("URL final:", response.url)
