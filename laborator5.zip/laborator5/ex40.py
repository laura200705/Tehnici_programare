# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

import hashlib

def page_fingerprint(url):
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()


fingerprint1 = page_fingerprint(BASE_URL)
fingerprint2 = page_fingerprint(BASE_URL)

print("Prima amprentă:", fingerprint1)
print("A doua amprentă:", fingerprint2)

print("Sunt identice:", fingerprint1 == fingerprint2)

#Amprentele ar fi diferite dacă și conținutul primit de la server este diferit, de exemplu dacă pagina a fost modificată sau serverul generează conținut dinamic.