# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

def log(message, **details):
    print(message, end="")

    for name, value in details.items():
        print(" | " + name + "=" + str(value), end="")

    print()


log("verificat", url=BASE_URL, status=200)

#print() - afișează valoarea pe ecran, dar nu o transmite mai departe.
#return - returnează valoarea din funcție, astfel încât să poată fi salvată într-o variabilă, folosită într-un calcul sau transmisă altei funcții.