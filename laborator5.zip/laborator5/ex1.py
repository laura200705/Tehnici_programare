#Laborator: functii, metode si importuri pe web
#Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 #secunde
import requests 

print(requests.__version__)

import urllib.request
print(urllib.request)
#requests trebuie instalat separat, iar urllib.request face parte din biblioteca standard python

