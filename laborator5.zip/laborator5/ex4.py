#Laborator: functii, metode si importuri pe web
#Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 #secunde

import urllib.request

request = urllib.request.Request(BASE_URL)
request.add_header("User-Agent", "Mozilla/5.0")

response = urllib.request.urlopen(request)

print(response.status)

data = response.read()

print(data[:200].decode("utf-8"))