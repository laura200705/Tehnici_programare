# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

def fetch(url, timeout=10):
    """Returnează obiectul răspuns."""
    response = requests.get(url, timeout=timeout)
    return response

# Apel cu valoarea implicită timeout=10
response1 = fetch(BASE_URL)
print(response1.status_code)

# Apel cu timeout=3
response2 = fetch(BASE_URL, timeout=3)
print(response2.status_code)