# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

import re

def extract_links(html):
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))


response = requests.get(BASE_URL)
print(extract_links(response.text))