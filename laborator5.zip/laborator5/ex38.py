# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

from urllib.parse import urljoin, urlparse

def split_links(links, domain):
    internal = []
    external = []

    for link in links:
        full_url = urljoin(BASE_URL, link)

        if urlparse(full_url).netloc == domain:
            internal.append(full_url)
        else:
            external.append(full_url)

    return internal, external


links = ["/about", "contact.html", "https://google.com"]

internal, external = split_links(links, "cybercor.org")

print("Interne:", internal)
print("Externe:", external)