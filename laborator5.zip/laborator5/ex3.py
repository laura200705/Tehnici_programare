#Laborator: functii, metode si importuri pe web
#Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 #secunde


import requests as rq
response = rq.get(BASE_URL)
print(response.status_code)
 #Aliasul face codul mai scurt si mai usor de scris, insa daca aliasul nu este cunoscut, codul poate fi mai greu de citit