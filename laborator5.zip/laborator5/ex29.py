# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

def get_header(url: str, name: str, default="lipsește"):
    response = requests.get(url, timeout=TIMEOUT)
    return response.headers.get(name, default)

print(get_header(BASE_URL, name="Server"))