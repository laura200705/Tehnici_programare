# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

def check_paths(base: str, paths: list) -> dict:
    result = {}

    for path in paths:
        response = requests.get(base + path, timeout=TIMEOUT)
        result[path] = response.status_code

    return result

paths = ["/", "/robots.txt", "/sitemap.xml"]

print(check_paths(BASE_URL, paths))