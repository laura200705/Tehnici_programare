#Laborator: functii, metode si importuri pe web
#Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 #secunde

import requests
response = requests.get(BASE_URL)
print(response.status_code)
#Avantaj: get() deja apartine modulului requests

from requests import get
response = get(BASE_URL)
print(response.status_code)
#Avantaj: codul este mai scurt