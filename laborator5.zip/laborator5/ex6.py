#Laborator: functii, metode si importuri pe web
#Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"


import requests
#help(requests.get)

r = requests.get(BASE_URL, timeout=5)
print(r.status_code)
