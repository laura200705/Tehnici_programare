# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

def fetch_robots(base: str):
    response = requests.get(base + "/robots.txt", timeout=TIMEOUT)

    if response.status_code == 200:
        return response.text

    return None


def disallowed_paths(robots_text):
    if robots_text is None:
        return []

    result = []

    for line in robots_text.splitlines():
        line = line.strip()

        if line.startswith("Disallow:"):
            path = line[len("Disallow:"):].strip()
            result.append(path)

    return result


robots = fetch_robots(BASE_URL)
print(disallowed_paths(robots))