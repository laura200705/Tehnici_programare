# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

TIMEOUT = 10 # secunde

import requests

def fetch(url):
    """Returnează obiectul răspuns."""
    response = requests.get(url, timeout=TIMEOUT)
    return response


def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


def get_title(html):
    """Returnează titlul paginii din codul HTML."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    return html[start:end].strip()


def security_headers(url):
    """Verifică prezența antetelor de securitate."""
    response = requests.get(url, timeout=TIMEOUT)

    headers = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]

    result = {}

    for header in headers:
        result[header] = header in response.headers

    return result

if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))