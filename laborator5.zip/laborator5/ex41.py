# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

import json

def save_headers(url):
    response = requests.get(url, timeout=TIMEOUT)

    with open("headers.json", "w") as file:
        json.dump(dict(response.headers), file, indent=2)


def load_headers():
    with open("headers.json", "r") as file:
        return json.load(file)


save_headers(BASE_URL)

headers = load_headers()

print(headers["Server"])