# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

response = requests.get(BASE_URL)

html = response.text

start = html.find("<title>") + len("<title>")
end = html.find("</title>")

print(html[start:end].strip())