# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

from urllib.parse import urlparse

def parse_url(url):
    result = urlparse(url)

    print("scheme:", result.scheme)
    print("netloc:", result.netloc)
    print("path:", result.path)
    print("query:", result.query)
    print("fragment:", result.fragment)


parse_url("https://cybercor.org/path?x=1#top")