# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10 # secunde

import requests

response = requests.get(BASE_URL)

print(response.text.lower().count("cyber"))

#lower() - pentru citirea textului in minuscula, pentru a nu fi mai multe forme de scriere precum:CYBER/Cyber/cyber
#count() - pentru numararea de cate ori apare "cyber"

