# Laborator: functii, metode si importuri pe web
# Student: Vizitiu Laura

TIMEOUT = 10 # secunde

import argparse
import csv
from datetime import datetime

import webtools
from webtools import DEFAULT_HEADERS

parser = argparse.ArgumentParser()
parser.add_argument("url", help="Adresa URL")
args = parser.parse_args()

print(webtools.get_title(webtools.fetch(args.url).text))

# Se executa doar in primul caz (python3 webtools.py),
# pentru ca doar importa functiile din webtools.py,
# iar autotestul nu se executa.

print(DEFAULT_HEADERS)
webtools.site_report(args.url)

paths = ["/", "/robots.txt", "/sitemap.xml"]
results = webtools.check_paths(args.url, paths)

with open("report.csv", "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["path", "status", "checked_at"])

    for path, status in results.items():
        writer.writerow([path, status, datetime.now().isoformat()])
