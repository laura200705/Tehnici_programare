#Laborator: functii, metode si importuri pe web
#Student: Vizitiu Laura

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
import time
import requests
start = time.perf_counter()

response = requests.get(BASE_URL)

end = time.perf_counter()
print(response.elapsed)